package com.hoaxify.hoaxify;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.hoaxify.hoaxify.error.ApiError;
import com.hoaxify.hoaxify.shared.GenericResponse;
import com.hoaxify.hoaxify.user.User;
import com.hoaxify.hoaxify.user.UserRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class UserControllerTest {

	private static final String API_1_0_USERS = "/api/1.0/users";
	@Autowired
	TestRestTemplate testRestTemplate;
	@Autowired
	UserRepository userRepository;

	@Before
	public void cleanup() {
		userRepository.deleteAll();
	}

	@Test
	public void postUser_whenUserIsValid_returnOk() {
		User user = createUser();

		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

	}

	private User createUser() {
		User user = new User();
		user.setUsername("test-user");
		user.setDisplayName("test-user");
		user.setPassword("P4ssword");
		return user;
	}

	@Test
	public void postUser_whenUserIsValid_userSavedInDatabase() {
		User user = createUser();

		postSignUp(user, Object.class);

		assertThat(userRepository.count()).isEqualTo(1);

	}

	@Test
	public void postUser_whenUserIsValid_receivedSuccessMessage() {
		User user = createUser();

		ResponseEntity<GenericResponse> response = postSignUp(user, GenericResponse.class);
		assertThat(response.getBody().getMessage()).isNotNull();

	}

	public <T> ResponseEntity<T> postSignUp(Object request, Class<T> response) {
		return testRestTemplate.postForEntity(API_1_0_USERS, request, response);
	}

	@Test
	public void postUser_whenUserIsValid_passwordIsHashedInDatabase() {
		User user = createUser();

		postSignUp(user, GenericResponse.class);
		List<User> users = userRepository.findAll();
		User userInDB = users.get(0);
		assertThat(userInDB.getPassword()).isNotEqualTo(user.getPassword());

	}

	@Test
	public void postUser_whenUserHasNullUsername_returnBadRequest() {
		User user = createUser();
		user.setUsername(null);
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasDisplayName_returnBadRequest() {
		User user = createUser();
		user.setDisplayName(null);
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasNullPassword_returnBadRequest() {
		User user = createUser();
		user.setPassword(null);
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasUsernameWithLessThanRequired_returnBadRequest() {
		User user = createUser();
		user.setUsername("abc");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasDisplayNameWithLessThanRequired_returnBadRequest() {
		User user = createUser();
		user.setDisplayName("abc");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasPasswordWithLessThanRequired_returnBadRequest() {
		User user = createUser();
		user.setPassword("P4ss");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasUsernameThatExceedsLimitRequired_returnBadRequest() {
		User user = createUser();
		String userNameLengthIs256 = IntStream.rangeClosed(1, 256).mapToObj(x -> "1").collect(Collectors.joining());
		user.setUsername(userNameLengthIs256);
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasDisplayNameThatExceedsLimitRequired_returnBadRequest() {
		User user = createUser();
		String userNameLengthIs256 = IntStream.rangeClosed(1, 256).mapToObj(x -> "1").collect(Collectors.joining());
		user.setDisplayName(userNameLengthIs256);
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasPasswordThatExceedsLimitRequired_returnBadRequest() {
		User user = createUser();
		String userNameLengthIs256 = IntStream.rangeClosed(1, 256).mapToObj(x -> "1").collect(Collectors.joining());
		user.setPassword(userNameLengthIs256 + "A1");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasPasswordWithAllLowercase_returnBadRequest() {
		User user = createUser();
		user.setPassword("lowercase");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasPasswordWithAllUppercase_returnBadRequest() {
		User user = createUser();
		user.setPassword("UPPERCASE");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}

	@Test
	public void postUser_whenUserHasPasswordWithAllNumber_returnBadRequest() {
		User user = createUser();
		user.setPassword("12345678");
		ResponseEntity<Object> response = postSignUp(user, Object.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}
	
	@Test
	public void postUser_whenUserIsInvalid_receiceApiError() {
		User user = createUser();
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		String url = response.getBody().getUrl();
		assertThat(url).isEqualTo(API_1_0_USERS);

	}
	
	@Test
	public void postUser_whenUserIsInvalid_receiceApiErrorWithValidationErrors() {
		User user = createUser();
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		Map<String, String> validationErrors = response.getBody().getValidationErrors();
		assertThat(validationErrors.size()).isEqualTo(3);

	}
	
	@Test
	public void postUser_whenUserHasNullUsername_receiceMessageOfNullErrorForUsername() {
		User user = createUser();
		user.setUsername(null);
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		Map<String, String> validationErrors = response.getBody().getValidationErrors();
		assertThat(validationErrors.get("username")).isEqualTo("username cannot be null");

	}
	
	@Test
	public void postUser_whenUserHasNullDisplayname_receiceGenericMessageOfNullError() {
		User user = createUser();
		user.setDisplayName(null);
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		Map<String, String> validationErrors = response.getBody().getValidationErrors();
		assertThat(validationErrors.get("displayName")).isEqualTo("Cannot be null");

	}
	
	@Test
	public void postUser_whenUserHasInvalidLengthUsername_receiceGenericMessageOfSizeError() {
		User user = createUser();
		user.setUsername("abc");
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		Map<String, String> validationErrors = response.getBody().getValidationErrors();
		assertThat(validationErrors.get("username")).isEqualTo("It must have minimum 4 and maximum 255 characters");

	}
	
	@Test
	public void postUser_whenUserHasInvalidPasswordPattern_receiceMessageOfPasswordPatternError() {
		User user = createUser();
		user.setPassword("lowercase");
		ResponseEntity<ApiError> response = postSignUp(user, ApiError.class);
		Map<String, String> validationErrors = response.getBody().getValidationErrors();
		assertThat(validationErrors.get("password")).isEqualTo("Password must have at least one uppercase, one lowercase letter and one number");

	}

}
